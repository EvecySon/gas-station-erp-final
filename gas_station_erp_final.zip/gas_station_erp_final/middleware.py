from functools import wraps
from flask import redirect, url_for, session, flash

def login_required(role=None):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if 'user_id' not in session:
                flash('Login required', 'warning')
                return redirect(url_for('auth.login'))
            if role and session.get('role') != role:
                flash('Unauthorized', 'danger')
                return redirect(url_for('dashboard.index'))
            return f(*args, **kwargs)
        return wrapper
    return decorator