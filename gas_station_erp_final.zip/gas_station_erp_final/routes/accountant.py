from flask import Blueprint, render_template
from middleware import login_required

bp = Blueprint('accountant', __name__, url_prefix='/accountant')

@bp.route('/dashboard')
@login_required(role='accountant')
def dashboard():
    return render_template('accountant_dashboard.html')