from flask import Blueprint, render_template
from middleware import login_required

bp = Blueprint('cashier', __name__, url_prefix='/cashier')

@bp.route('/dashboard')
@login_required(role='cashier')
def dashboard():
    return render_template('new_sale.html')