class Config:
    SQLALCHEMY_DATABASE_URI = 'sqlite:///gas_station.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False