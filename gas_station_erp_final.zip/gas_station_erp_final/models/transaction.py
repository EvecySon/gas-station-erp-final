from app import db
from datetime import datetime

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_name = db.Column(db.String(100))
    product_id = db.Column(db.Integer)
    quantity = db.Column(db.Float)
    price_per_kg = db.Column(db.Float)
    total_price = db.Column(db.Float)
    station_id = db.Column(db.Integer)
    pump_id = db.Column(db.Integer)
    cashier_name = db.Column(db.String(100))
    attendant_name = db.Column(db.String(100))
    date_time = db.Column(db.DateTime, default=datetime.utcnow)